# finalflash

`finalflash` is a tool that corrects radio interferometric images using the uGMRT primary beam model for different observing bands.

## Installation

Install using pip: pip install finalflash



After installation, the command-line tool `finalflash` can be used to correct FITS files.

finalflash <input_fits> <output_fits>
